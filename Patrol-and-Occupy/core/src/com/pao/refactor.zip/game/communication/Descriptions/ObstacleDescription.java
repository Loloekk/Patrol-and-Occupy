package com.pao.game.communication.Descriptions;

public abstract class ObstacleDescription extends ObjectDescription{
    public ObstacleDescription()
    {
        super();
    }
}
