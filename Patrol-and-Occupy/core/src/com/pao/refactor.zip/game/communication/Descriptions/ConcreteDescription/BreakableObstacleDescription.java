package com.pao.game.communication.Descriptions.ConcreteDescription;

import com.pao.game.communication.Descriptions.ObstacleDescription;

public class BreakableObstacleDescription extends ObstacleDescription {
    public BreakableObstacleDescription()
    {
        super();
    }
}
