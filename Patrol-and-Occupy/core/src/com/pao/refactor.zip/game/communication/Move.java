package com.pao.game.communication;

public enum Move {
    Forward,Back,Left,Right,Shoot,Dynamite;
}