package com.pao.game.communication.Descriptions.ConcreteDescription;

import com.pao.game.communication.Descriptions.ObjectDescription;

public class DynamiteDescription extends ObjectDescription {
    public DynamiteDescription(){
        super();
    }
}
