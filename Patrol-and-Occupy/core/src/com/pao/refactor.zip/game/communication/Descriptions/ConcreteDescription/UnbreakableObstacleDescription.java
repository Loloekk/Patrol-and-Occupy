package com.pao.game.communication.Descriptions.ConcreteDescription;

import com.pao.game.communication.Descriptions.ObstacleDescription;
import com.pao.game.model.GameObject.Obstacles.UnbreakableObstacle.UnbreakableObstacle;

public class UnbreakableObstacleDescription extends ObstacleDescription {
    public UnbreakableObstacleDescription()
    {
        super();
    }
}
