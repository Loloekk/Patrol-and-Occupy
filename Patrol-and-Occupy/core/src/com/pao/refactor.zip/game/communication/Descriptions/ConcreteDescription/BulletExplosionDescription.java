package com.pao.game.communication.Descriptions.ConcreteDescription;

import com.pao.game.communication.Descriptions.ExplosionDescription;

public class BulletExplosionDescription extends ExplosionDescription {
    public BulletExplosionDescription()
    {
        super();
    }
}
