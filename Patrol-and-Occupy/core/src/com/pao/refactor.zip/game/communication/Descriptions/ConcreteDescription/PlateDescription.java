package com.pao.game.communication.Descriptions.ConcreteDescription;

import com.pao.game.communication.Descriptions.ColoredObjectDescription;

public class PlateDescription extends ColoredObjectDescription {
    public PlateDescription() {
        super();
    }
}
