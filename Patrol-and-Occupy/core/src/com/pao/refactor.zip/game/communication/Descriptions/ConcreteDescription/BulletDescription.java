package com.pao.game.communication.Descriptions.ConcreteDescription;

import com.pao.game.communication.Descriptions.ObjectDescription;

public class BulletDescription extends ObjectDescription {
    public BulletDescription(){
        super();
    }
}
