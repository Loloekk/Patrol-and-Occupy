package com.pao.game.communication.Descriptions.ConcreteDescription;

import com.pao.game.communication.Descriptions.ExplosionDescription;

public class DynamiteExplosionDescription extends ExplosionDescription {
    public DynamiteExplosionDescription(){
        super();
    }
}
