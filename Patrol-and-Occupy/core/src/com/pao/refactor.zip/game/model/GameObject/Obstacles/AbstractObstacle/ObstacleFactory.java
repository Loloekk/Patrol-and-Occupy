package com.pao.game.model.GameObject.Obstacles.AbstractObstacle;

public class ObstacleFactory {
    public ObstacleCreatingParams getNew()
    {
        return null;
    }
}
